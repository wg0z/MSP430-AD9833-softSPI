// AD9833_MSP430_main.c
//
//




#include <msp430.h>				

#include "AD9833_named_numbers.h"
#include "AD9833_prototypes.h"


void main(void)
{
	WDTCTL = WDTPW | WDTHOLD;		// stop watchdog timer

	AD9833_if_init();

	// perform the setup define by AN-1070
    AD9833_Select();
    AD9833_writeDevice(0x2100);
    AD9833_writeDevice(0x50C7);
    AD9833_writeDevice(0x4000);
    AD9833_writeDevice(0xC000);
    AD9833_writeDevice(0x2000);
    AD9833_Deselect();

	for(;;)
	{
	    ;
	} // end for(ever)

} // end main()

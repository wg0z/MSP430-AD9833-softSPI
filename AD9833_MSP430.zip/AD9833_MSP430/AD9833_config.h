/*
 * AD9833_config.h
 *
 *  Created on: Jul 31, 2017
 *      Author: JJH
 */

#ifndef AD9833_CONFIG_H_
#define AD9833_CONFIG_H_




#define DATA_DIRPORT    P1DIR
#define DATA_OUTPORT    P1OUT
#define DATA_BIT_NUM    0
#define DATA_BIT_MASK   (1 << DATA_BIT_NUM)

#define CLK_DIRPORT     P1DIR
#define CLK_OUTPORT     P1OUT
#define CLK_BIT_NUM     1
#define CLK_BIT_MASK    (1 << CLK_BIT_NUM)

#define FSYNC_DIRPORT    P1DIR
#define FSYNC_OUTPORT    P1OUT
#define FSYNC_BIT_NUM    2
#define FSYNC_BIT_MASK   (1 << FSYNC_BIT_NUM)


#endif /* AD9833_CONFIG_H_ */

/*
 * AD9833_named_numbers.h
 *
 *  Created on: Aug 1, 2017
 *      Author: JJH
 */

#ifndef AD9833_NAMED_NUMBERS_H_
#define AD9833_NAMED_NUMBERS_H_

#define CTL     0
#define FREQ_0  0x4000
#define FREQ_1  0x8000
#define PHASE_0 0xC000
#define PHASE_1 0xE000

#define B28_FLAG 0x2000

#endif /* AD9833_NAMED_NUMBERS_H_ */

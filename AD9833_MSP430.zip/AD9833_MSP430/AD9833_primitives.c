/*
 * AD9833_primitives.c
 *
 *  Created on: Jul 31, 2017
 *      Author: JJH
 */

#include <msp430.h>

#include "AD9833_config.h"
#include "AD9833_prototypes.h"


#define FSYNC_LO FSYNC_OUTPORT &= ~FSYNC_BIT_MASK
#define FSYNC_HI FSYNC_OUTPORT |= FSYNC_BIT_MASK

#define DATA_LO DATA_OUTPORT &= ~DATA_BIT_MASK
#define DATA_HI DATA_OUTPORT |= DATA_BIT_MASK

#define CLK_LO CLK_OUTPORT &= ~CLK_BIT_MASK
#define CLK_HI CLK_OUTPORT |= CLK_BIT_MASK


void AD9833_if_init( void )
{
    // set 3 signals to HIGH
    FSYNC_HI;
    DATA_HI;
    CLK_HI;

    // set 3 signals to be OUTPUTS
    FSYNC_DIRPORT = FSYNC_DIRPORT | FSYNC_BIT_MASK;
    DATA_DIRPORT = DATA_DIRPORT | DATA_BIT_MASK;
    CLK_DIRPORT = CLK_DIRPORT | CLK_BIT_MASK;
}

void AD9833_writeDevice( unsigned Word )
{
    unsigned Mask = 0x8000;

    // CLK is HIGH as this function is entered and exited
    // this function writes 16 bits but does NOT control FSYNC.
    do
    {
      if (Word & Mask)
          DATA_HI;
      else
          DATA_LO;
      CLK_LO;
      CLK_HI;
      Mask = Mask >> 1;
    } while (Mask);
}


void AD9833_Select( void )
{
    FSYNC_LO;
}

void AD9833_Deselect( void )
{
    FSYNC_HI;
}



/*
 * AD9833_prototypes.h
 *
 *  Created on: Jul 31, 2017
 *      Author: JJH
 */

#ifndef AD9833_PROTOTYPES_H_
#define AD9833_PROTOTYPES_H_

void AD9833_if_init( void );
void AD9833_writeDevice( unsigned Word );
void AD9833_Select( void );
void AD9833_Deselect( void );

#endif /* AD9833_PROTOTYPES_H_ */
